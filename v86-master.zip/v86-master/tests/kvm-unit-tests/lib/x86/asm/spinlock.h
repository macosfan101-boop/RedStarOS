#ifndef __ASM_SPINLOCK_H
#define __ASM_SPINLOCK_H

#include <asm-generic/spinlock.h>

#endif
